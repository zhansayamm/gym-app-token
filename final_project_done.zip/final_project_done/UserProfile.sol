// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract UserProfile {
    struct User {
        string username;
        string email;
        address account;
    }

    mapping(address => User) private users;
    mapping(address => bool) private registered;
    event UserRegistered(address user, string username, string email);
    function register(string memory _username, string memory _email) public {
        require(!registered[msg.sender], "User already registered");
        require(bytes(_username).length > 0, "Username required");
        require(bytes(_email).length > 0, "Email required");
        users[msg.sender] = User({
            username: _username,
            email: _email,
            account: msg.sender
        });

        registered[msg.sender] = true;

        emit UserRegistered(msg.sender, _username, _email);
    }
    function getUser(address _addr) public view returns (
        string memory username,
        string memory email,
        address account
    ) {
        require(registered[_addr], "User not found");

        User memory user = users[_addr];

        return (user.username, user.email, user.account);
    }
    function isRegistered(address _addr) public view returns (bool) {
        return registered[_addr];
    }
}